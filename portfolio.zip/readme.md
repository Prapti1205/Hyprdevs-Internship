# Personal Portfolio Website

A visually rich and interactive personal portfolio website built using HTML, CSS, and JavaScript. Ideal for showcasing projects, skills, and contact information.

## Features

- 🌐 Clean and modern UI
- 🎨 Custom styles via CSS
- 📸 Image assets for enhanced visual appeal
- ✨ JavaScript for interactivity

## Technologies Used

- HTML5
- CSS3
- JavaScript (Vanilla)

## Installation

1. Download or clone the repository.
2. Extract the contents if it's in a ZIP format.
3. Open `Untitled-2.html` in your web browser.

## File Structure
portfolio_project/
│
├── Untitled-2.html # Main HTML structure
├── Untitled-2.css # Stylesheet
├── Untitled-2.js # JavaScript functionality
├── 120.jpg # Image asset
├── 121.jpg # Image asset
├── 123.jpg # Image asset
├── 124.jpg # Image asset
└── new.svg # Vector graphic

## How to Use

1. Customize text and image sections in `Untitled-2.html`.
2. Modify styling in `Untitled-2.css` to match your personal brand.
3. Add interactivity or animations in `Untitled-2.js`.

## License

This project is available for personal or educational use. Free to modify and redistribute with attribution.