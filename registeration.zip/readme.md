# Registration System Web Project

This is a front-end registration and landing page project built with HTML, CSS, and image assets. It features multiple HTML pages with corresponding CSS styles, designed for a smooth user interface and visual appeal.

## Features

- 📄 Multiple HTML pages including:
  - **Landing Page** (`landing.html`)
  - **Registration Page** (`registeration.html`)
  - **New Template Page** (`newtemp.html`)
- 🎨 Custom styling with:
  - `landing.css`
  - `temp.css`
- 🖼️ Visually appealing images used across pages:
  - `hyperdev4.jpg`, `hyprdev1.jpg`, `hyprdev2.jpg`, `hyprdev3.jpg`, `new.jpg`

## Installation

1. Clone or download the repository.
2. Extract the contents if zipped.
3. Open `landing.html` in your web browser to begin exploring the site.

## Usage

- Modify the HTML files to customize content.
- Adjust the CSS files to tweak design and layout.
- Replace or add new images for personalization.

## File Structure

registration_project/
│
├── landing.html
├── registeration.html
├── newtemp.html
├── landing.css
├── temp.css
├── hyperdev4.jpg
├── hyprdev1.jpg
├── hyprdev2.jpg
├── hyprdev3.jpg
└── new.jpg


## License

This project is open for personal or educational use. Feel free to modify and extend it.